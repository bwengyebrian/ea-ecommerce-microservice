package edu.mum.cs.ea.creditpaymentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditPaymentServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
