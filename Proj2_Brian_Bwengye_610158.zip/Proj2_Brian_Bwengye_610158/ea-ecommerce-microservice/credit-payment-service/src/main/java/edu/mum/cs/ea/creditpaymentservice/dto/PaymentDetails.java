package edu.mum.cs.ea.creditpaymentservice.dto;

public class PaymentDetails {
}
