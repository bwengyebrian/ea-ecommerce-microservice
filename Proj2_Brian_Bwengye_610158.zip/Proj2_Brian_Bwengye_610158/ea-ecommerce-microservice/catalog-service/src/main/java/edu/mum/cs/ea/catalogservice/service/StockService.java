package edu.mum.cs.ea.catalogservice.service;

public interface StockService {


}
