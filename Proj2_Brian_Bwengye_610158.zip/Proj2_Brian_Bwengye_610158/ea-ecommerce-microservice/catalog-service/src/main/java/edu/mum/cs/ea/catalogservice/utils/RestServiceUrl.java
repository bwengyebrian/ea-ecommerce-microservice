package edu.mum.cs.ea.catalogservice.utils;

import org.springframework.beans.factory.annotation.Value;

public class RestServiceUrl {
    //public static final   String CATALOG_SERVICE_URL= "http://stock-service.default.svc.cluster.local:8080/product";
    public static final   String CATALOG_SERVICE_URL= "http://stock-service.default.svc.cluster.local:8080/product";
}
