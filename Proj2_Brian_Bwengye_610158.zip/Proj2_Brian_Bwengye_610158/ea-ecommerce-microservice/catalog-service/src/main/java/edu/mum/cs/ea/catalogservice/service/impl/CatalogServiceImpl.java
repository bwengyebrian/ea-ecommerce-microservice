package edu.mum.cs.ea.catalogservice.service.impl;


public class CatalogServiceImpl  {
//    @Autowired
//    private StockServiceFeign stockServiceFeign;
//    @Override
//    public List<Product> getHomeProducts() {
//        List<Product> products = new ArrayList<>();
//        try {
//            JSONArray jsonArray = new JSONArray(stockServiceFeign.getProducts());
//
//            for (int i = 0 ; i < jsonArray.length();i++) {
//                JSONObject jsonObject =jsonArray.getJSONObject(i);
//                Product product = new Product();
//                product.setProductId((String) jsonObject.get("id"));
//                product.setProductName((String) jsonObject.get("productName"));
//                product.setProductName((String) jsonObject.get("price"));
//                products.add(product);
//            }
//
//        }
//        catch (JSONException e){
//            System.out.println(e.getMessage());
//        }
//
//        return products;
//    }
}
