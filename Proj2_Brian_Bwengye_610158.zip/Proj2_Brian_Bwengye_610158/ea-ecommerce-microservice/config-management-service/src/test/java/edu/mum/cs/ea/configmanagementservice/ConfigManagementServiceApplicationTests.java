package edu.mum.cs.ea.configmanagementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigManagementServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
