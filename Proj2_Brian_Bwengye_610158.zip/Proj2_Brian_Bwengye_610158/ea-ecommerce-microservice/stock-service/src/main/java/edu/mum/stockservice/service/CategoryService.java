package edu.mum.stockservice.service;

import edu.mum.stockservice.model.Category;

public interface CategoryService {

    Category saveCategory(Category category);
}
