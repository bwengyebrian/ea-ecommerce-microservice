package edu.mum.stockservice.service;

import edu.mum.stockservice.model.Vendor;

public interface VendorService {

    Vendor saveVendor(Vendor vendor);
}
