package edu.mum.stockservice.model;

import lombok.Data;

@Data
public class OrderedProduct {

    private long id;
    private int amount;
}
