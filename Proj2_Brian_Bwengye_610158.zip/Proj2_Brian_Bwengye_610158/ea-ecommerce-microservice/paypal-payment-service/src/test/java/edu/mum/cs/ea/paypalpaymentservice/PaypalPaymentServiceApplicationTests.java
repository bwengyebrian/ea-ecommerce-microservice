package edu.mum.cs.ea.paypalpaymentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaypalPaymentServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
