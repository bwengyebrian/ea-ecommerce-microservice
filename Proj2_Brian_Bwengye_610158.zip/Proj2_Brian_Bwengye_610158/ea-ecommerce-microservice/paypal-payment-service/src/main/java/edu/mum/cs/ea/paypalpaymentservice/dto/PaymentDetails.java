package edu.mum.cs.ea.paypalpaymentservice.dto;

public class PaymentDetails {
}
