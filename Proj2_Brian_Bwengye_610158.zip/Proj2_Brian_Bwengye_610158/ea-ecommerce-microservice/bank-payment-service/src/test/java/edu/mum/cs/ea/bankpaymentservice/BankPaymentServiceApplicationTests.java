package edu.mum.cs.ea.bankpaymentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankPaymentServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
