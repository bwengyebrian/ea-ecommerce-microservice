package edu.mum.cs.ea.bankpaymentservice.dto;

public class PaymentDetails {
}
